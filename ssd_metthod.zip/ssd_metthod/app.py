import os
import cv2
import numpy as np
import tensorflow as tf
from tensorflow.keras.models import load_model
from flask import Flask, request, render_template
from werkzeug.utils import secure_filename
import statistics as st
import logging

# Set up logging for debugging
logging.basicConfig(level=logging.DEBUG)

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index1.html")


@app.route('/camera', methods=['GET', 'POST'])
def camera():
    i = 0
    GR_dict = {0: (0, 255, 0), 1: (0, 0, 255)}
    output = []

    try:
        # Load the model
        model = tf.keras.models.load_model('final_model.keras')
        logging.info("Model loaded successfully.")

        # Load the face cascade for detecting faces
        face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

        # Open the webcam
        cap = cv2.VideoCapture(0)

        if not cap.isOpened():
            logging.error("Error: Could not access the camera.")
            return "Error: Could not access the camera."

        while i <= 30:
            ret, img = cap.read()

            if not ret:
                logging.error("Failed to capture image.")
                continue

            faces = face_cascade.detectMultiScale(img, scaleFactor=1.05, minNeighbors=5)

            for x, y, w, h in faces:
                face_img = img[y:y + h, x:x + w]

                resized = cv2.resize(face_img, (96, 96))
                reshaped = resized.reshape(1, 96, 96, 3) / 255.0  # Normalize image

                predictions = model.predict(reshaped)
                max_index = np.argmax(predictions[0])

                emotions = ('angry', 'disgust', 'fear', 'happy', 'sad', 'neutral', 'surprise')
                predicted_emotion = emotions[max_index]
                output.append(predicted_emotion)

                cv2.rectangle(img, (x, y), (x + w, y + h), GR_dict[1], 2)
                cv2.rectangle(img, (x, y - 40), (x + w, y), GR_dict[1], -1)
                cv2.putText(img, predicted_emotion, (x, y - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 255, 255), 2)

            i += 1

            cv2.imshow('LIVE', img)

            key = cv2.waitKey(1)
            if key == 27:  # ESC key to break the loop
                cap.release()
                cv2.destroyAllWindows()
                break

        logging.info("Predictions output: %s", output)
        cap.release()
        cv2.destroyAllWindows()

        final_output1 = st.mode(output)
        return render_template("buttons.html", final_output=final_output1)

    except Exception as e:
        logging.error("An error occurred: %s", e)
        return f"An error occurred: {e}"


@app.route('/templates/buttons', methods=['GET', 'POST'])
def buttons():
    return render_template("buttons.html")


@app.route('/movies/surprise', methods=['GET', 'POST'])
def moviesSurprise():
    return render_template("moviesSurprise.html")


@app.route('/movies/angry', methods=['GET', 'POST'])
def moviesAngry():
    return render_template("moviesAngry.html")


@app.route('/movies/sad', methods=['GET', 'POST'])
def moviesSad():
    return render_template("moviesSad.html")


@app.route('/movies/disgust', methods=['GET', 'POST'])
def moviesDisgust():
    return render_template("moviesDisgust.html")


@app.route('/movies/happy', methods=['GET', 'POST'])
def moviesHappy():
    return render_template("moviesHappy.html")


@app.route('/movies/fear', methods=['GET', 'POST'])
def moviesFear():
    return render_template("moviesFear.html")


@app.route('/movies/neutral', methods=['GET', 'POST'])
def moviesNeutral():
    return render_template("moviesNeutral.html")


@app.route('/songs/surprise', methods=['GET', 'POST'])
def songsSurprise():
    return render_template("songsSurprise.html")


@app.route('/songs/angry', methods=['GET', 'POST'])
def songsAngry():
    return render_template("songsAngry.html")


@app.route('/songs/sad', methods=['GET', 'POST'])
def songsSad():
    return render_template("songsSad.html")


@app.route('/songs/disgust', methods=['GET', 'POST'])
def songsDisgust():
    return render_template("songsDisgust.html")


@app.route('/songs/happy', methods=['GET', 'POST'])
def songsHappy():
    return render_template("songsHappy.html")


@app.route('/songs/fear', methods=['GET', 'POST'])
def songsFear():
    return render_template("songsFear.html")


@app.route('/songs/neutral', methods=['GET', 'POST'])
def songsNeutral():
    return render_template("songsSad.html")


@app.route('/templates/join_page', methods=['GET', 'POST'])
def join():
    return render_template("join_page.html")


if __name__ == "__main__":
    app.run(debug=True, use_reloader=False)
